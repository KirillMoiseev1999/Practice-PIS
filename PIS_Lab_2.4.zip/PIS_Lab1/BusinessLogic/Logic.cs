﻿using PIS_Lab1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class Logic
    {

        static public string RemovingSpaces(string str)
        {
            string result = Regex.Replace(str.Trim(), @"\s+", " ");
            return result;
        }

        static public string RemoveOption(string str)
        {
            string result = str.Substring(str.IndexOf("'") );
            return result;
        }

        static public Sea ParsFirst(string str)
        {
            string possibleName = str.Substring(str.IndexOf("'") + 1, str.LastIndexOf("'") - str.IndexOf("'") -1);

            str = str.Substring(str.LastIndexOf("'") + 1);
            string[] dividedParts = str.Trim().Split(' ');

            double possibleDepth = double.Parse(dividedParts[0]);
            double possibleSalinity = double.Parse(dividedParts[1]);

            return new Sea( possibleName, possibleDepth, possibleSalinity);
        }

        static public InlandSea ParsSecond(string str)
        {
            string possibleName = str.Substring(str.IndexOf("'") + 1, str.LastIndexOf("'") - str.IndexOf("'") -1);

            str = str.Substring(str.LastIndexOf("'") + 1);
            string[] dividedParts = str.Trim().Split(' ');

            double possibleDepth = double.Parse(dividedParts[0]);
            double possibleSalinity = double.Parse(dividedParts[1]);
            int possibleCount = int.Parse(dividedParts[2]);

            return new InlandSea(possibleName, possibleDepth, possibleSalinity, possibleCount);
        }

        static public MarginalSeas ParsThird(string str)
        {
            string possibleName = str.Substring(str.IndexOf("'") + 1, str.LastIndexOf("'") - str.IndexOf("'") - 1);

            str = str.Substring(str.LastIndexOf("'") + 1);
            string[] dividedParts = str.Trim().Split(' ');

            double possibleDepth = double.Parse(dividedParts[0]);
            double possibleSalinity = double.Parse(dividedParts[1]);
            bool possiblePort = bool.Parse(dividedParts[2]);

            return new MarginalSeas(possibleName, possibleDepth, possibleSalinity, possiblePort);
        }

    }
}
