﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic;
using System.IO;

namespace PIS_Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = "test.txt";
            string[] lines = File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                string nowString = Logic.removingSpaces(line);

            }


            //string inputStr = " 'Каспийское море' 123,5 14,3 ";
            //Sea obj = Logic.Pars(inputStr);
            //Console.WriteLine($"Море с назание \"{obj.name}\", глубиной {obj.depth} и соленостью {obj.salinity} ");


            //string str = " 1     2 3    4 ";
            //string newstr = Logic.removingSpaces(inputStr);
            //Console.WriteLine(newstr);

        }



    }
}
