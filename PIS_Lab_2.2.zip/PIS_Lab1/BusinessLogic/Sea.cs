﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIS_Lab1
{
    public class Sea
    {
        public int id;
        public string name;
        public double depth;
        public double salinity;

        public Sea(int _id, string _name, double _depth, double _salinity)
        {
            this.id = _id;
            this.name = _name;
            this.depth = _depth;
            this.salinity = _salinity;
        }

    }
}
