﻿using PIS_Lab1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class InlandSea : Sea
    {
        public int countCountries;
        public InlandSea(int _id, string _name, double _depth, double _salinity, int _countCountries) : 
            base(_id, _name, _depth, _salinity)
        {
            this.countCountries = _countCountries;
        }



    }
}
