﻿using PIS_Lab1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class MarginalSeas : Sea
    {
        public string oceanName;

        public MarginalSeas(int _id, string _name, double _depth, double _salinity, string _oceanName) : 
            base(_id, _name, _depth, _salinity)
        {
            this.oceanName = _oceanName;
        }
    }


}
