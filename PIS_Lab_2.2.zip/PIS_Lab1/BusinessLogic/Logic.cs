﻿using PIS_Lab1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class Logic
    {

        static public string removingSpaces(string str)
        {
            string result = Regex.Replace(str.Trim(), @"\s+", " ");
            return result;
        }


        //public static Sea Pars(string inputStr)
        //{
        //    string possibleName = inputStr.Substring(inputStr.IndexOf("'") + 1, inputStr.LastIndexOf("'") - inputStr.IndexOf("'") - 1);

        //    inputStr = inputStr.Substring(inputStr.LastIndexOf("'") + 1);
        //    string[] dividedParts = inputStr.Trim().Split(' ');

        //    double possibleDepth = double.Parse(dividedParts[0]);
        //    double possibleSalinity = double.Parse(dividedParts[1]);

        //    return new Sea(possibleName, possibleDepth, possibleSalinity);

        //}

        



    }
}
