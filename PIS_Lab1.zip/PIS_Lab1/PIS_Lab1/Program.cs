﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PIS_Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string inputStr = " 'Каспийское море' 123,5 14,3 ";

            Sea obj = Pars(inputStr);
            Console.WriteLine($"Море с назание \"{obj.Name}\", глубиной {obj.Depth} и соленостью {obj.Salinity} ");
            
        }
        static Sea Pars(string inputStr)
        {
            string possibleName = inputStr.Substring(inputStr.IndexOf("'") + 1, inputStr.LastIndexOf("'") - inputStr.IndexOf("'") - 1);

            inputStr = inputStr.Substring(inputStr.LastIndexOf("'") + 1);
            string[] dividedParts = inputStr.Trim().Split(' ');

            double possibleDepth = double.Parse(dividedParts[0]);
            double possibleSalinity = double.Parse(dividedParts[1]);

            return new Sea(possibleName, possibleDepth, possibleSalinity);

        }
    }
}
