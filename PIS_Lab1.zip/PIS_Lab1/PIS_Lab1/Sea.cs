﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PIS_Lab1
{
    internal class Sea
    {
        public string Name;
        public double Depth;
        public double Salinity;

        public Sea(string _name, double _depth, double _salinity)
        {
            Name = _name;
            Depth = _depth;
            Salinity = _salinity;
        }

    }
}
