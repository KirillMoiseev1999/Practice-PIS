﻿using PIS_Lab1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class MarginalSeas : Sea
    {
        public bool portАvailability;

        public MarginalSeas( string _name, double _depth, double _salinity, bool _portАvailability) : 
            base( _name, _depth, _salinity)
        {
            this.portАvailability = _portАvailability;
        }
    }


}
