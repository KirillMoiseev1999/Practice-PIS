﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic;
using System.IO;
using static System.Net.Mime.MediaTypeNames;

namespace PIS_Lab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ЧТЕНИЕ С ФАЙЛА 
            string filePath = "test.txt";
            string[] lines = File.ReadAllLines(filePath);

            // ЧТЕНИЕ СО СТРОКИ 
            //string linesX = "1 'Каспийское море' 123,5 14,3     \r\n " +
            //    "            2 'Внутреннее     море' 100      10   5 \r\n" +
            //    " 3 'Карское     море' 100      10   true \r\n         " +
            //    "3 'Арайское     море' 100      10   false \r\n" +
            //    "   1 'Каспийское           море' 1000    14,323113    \r\n" +
            //    "2  '_Qwerty     море' 1,3179      101   52";
            //string[] stringSeparators = new string[] { "\r\n" };
            //string[] lines = linesX.Split(stringSeparators, StringSplitOptions.None);


            foreach (string line in lines)
            {
                string nowString = Logic.removingSpaces(line);
                char option = nowString[0];
                nowString = Logic.removeOption(nowString);

                switch (option)
                {
                    case '1':
                        Sea obj1 = Logic.ParsFirst(nowString);
                        Console.WriteLine($"Море с назанием \"{obj1.name}\", глубиной {obj1.depth} и соленостью {obj1.salinity} ");
                        break;

                    case '2':
                        InlandSea obj2 = Logic.ParsSecond(nowString);
                        Console.WriteLine($"Море с назанием \"{obj2.name}\", глубиной {obj2.depth}, " +
                           $"соленостью {obj2.salinity} и числом прилегающих стран равным {obj2.countCountries} ");
                        break;

                    case '3':
                        MarginalSeas obj3 = Logic.ParsThird(nowString);
                        if (obj3.portАvailability == true)
                        {
                            Console.WriteLine($"Море с назанием \"{obj3.name}\", глубиной {obj3.depth}, " +
                                 $"соленостью {obj3.salinity} и наличием международного порта");
                        }
                        else
                        {
                            Console.WriteLine($"Море с назанием \"{obj3.name}\", глубиной {obj3.depth}, " +
                           $"соленостью {obj3.salinity} и отсуствием международного порта ");
                        }
                        
                        break;
                }
            }
        }
    }
}
